﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp5
{
    class 机器人
    {
        public string Jqr
        {
            get;
            set;
        }
        public int jqr()
        {
            Random rnd = new Random();
            int fist = rnd.Next(1, 4);
            switch (fist)
            {
                case 1: Jqr = "石头"; break;
                case 2: Jqr = "剪刀"; break;
                case 3: Jqr = "布"; break;
            }
            return fist;
        }
    }
}

